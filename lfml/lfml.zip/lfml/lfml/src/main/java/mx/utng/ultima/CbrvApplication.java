package mx.utng.ultima;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CbrvApplication {

	public static void main(String[] args) {
		SpringApplication.run(CbrvApplication.class, args);
	}

}
